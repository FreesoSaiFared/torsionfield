#!/usr/bin/env bash
set -euo pipefail
rm -f local.cow local-boot.log
set +e
timeout 60s ./linux-uml mem=128M ubd0=local.cow,master.img init=/init con=null con0=fd:0,fd:1 >local-boot.log 2>&1
rc=$?
set -e
echo "UML_EXIT=$rc" >> local-boot.log
grep -q 'UML_TEST_COMPLETE=1' local-boot.log
grep -q 'SENTINEL_BEFORE=ABSENT' local-boot.log
echo LOCAL_UML_BOOT=PASS
